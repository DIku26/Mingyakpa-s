import { AnnouncementBar } from './components/AnnouncementBar';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { FeaturedCarousel } from './components/FeaturedCarousel';
import { PortfolioSignup } from './components/PortfolioSignup';
import { BrandStrategyEvents } from './components/BrandStrategyEvents';
import { Testimonials } from './components/Testimonials';
import { FeaturedArticles } from './components/FeaturedArticles';
import { IndustryInsights } from './components/IndustryInsights';
import { NewsletterCTA } from './components/NewsletterCTA';
import { ThreeColumnSection } from './components/ThreeColumnSection';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-background">
      <AnnouncementBar />
      <Header />
      <main>
        <Hero />
        <FeaturedCarousel />
        <PortfolioSignup />
        <BrandStrategyEvents />
        <Testimonials />
        <FeaturedArticles />
        <IndustryInsights />
        <NewsletterCTA />
        <ThreeColumnSection />
      </main>
      <Footer />
    </div>
  );
}